filename="/$(whoami)/hadoop_setup/nodes"
downloadSoftware()
{
   wget "http://mirror.fibergrid.in/apache/spark/spark-2.1.1/spark-2.1.1-bin-hadoop2.7.tgz" -P /$(whoami)/hadoop_setup/
   echo "Downloaded"
}
copySoftware(){
   scp /$(whoami)/hadoop_setup/spark-2.1.1-bin-hadoop2.7.tgz $(whoami)@$1:/$(whoami)/hadoop_setup/
}
downloadSoftware
while read -r line
do
    echo "Copy software to machine: ***********************************************************************************"$line
    name="$line"
    copySoftware $name 
    echo "Done for machine        : ***********************************************************************************"$line
done < "$filename"

while read -r line
do
    name="$line"
    echo "${RED}Installing for Node:##################################################################################################### "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/install_spark.sh 
    echo "Done for Node:*************************************************************************************************************  "$name
done < "$filename"
