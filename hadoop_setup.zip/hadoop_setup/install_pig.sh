installPig(){
   rm -rf  /opt/software/pig-0.15
   wget "http://mirror.fibergrid.in/apache/pig/pig-0.15.0/pig-0.15.0.tar.gz" -P /$(whoami)/hadoop_setup/
   tar -zxvf /$(whoami)/hadoop_setup/pig-0.15.0.tar.gz -C /$(whoami)/hadoop_setup/
   mv /$(whoami)/hadoop_setup/pig-0.15.0        /opt/software/pig-0.15
   rm  -r  /$(whoami)/hadoop_setup/pig-0.15.0.tar.gz
}
configurePig(){
   cp /$(whoami)/hadoop_setup/resources/pig.properties    /opt/software/sqoop1.4.6/conf/pig-0.15
   chmod 777 -R /opt/software/pig-0.15

}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "PIG_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then

     echo "Setting PIG_HOME in .bashrc file path..."
     echo "export PIG_HOME=/opt/software/pig-0.15" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/pig-0.15/bin" >> ~/.bashrc
     exec bash
  else
    echo "PIG path is already exist in .bashrc file, skipping the path..."
  fi
}

installPig
configurePig
refreshBashRC