filename="/$(whoami)/hadoop_setup/nodes"
#before scp ssh should be establish , so that it will not fail with publickey issue
copySetUpFile(){
   echo "copying data to node ************************************************************************************************ "$1
   scp -r /$(whoami)/hadoop_setup $(whoami)@$1:/$(whoami)/
}
while read -r line
do
    name="$line"
    copySetUpFile $name
done < "$filename"
