filename="/$(whoami)/hadoop_setup/nodes"

downloadSoftware()
{
    wget "http://redrockdigimark.com/apachemirror/phoenix/phoenix-4.7.0-HBase-1.1/bin/phoenix-4.7.0-HBase-1.1-bin.tar.gz" -P /$(whoami)/hadoop_setup/
}
copySoftware(){
   scp /$(whoami)/hadoop_setup/phoenix-4.7.0-HBase-1.1-bin.tar.gz $(whoami)@$1:/$(whoami)/hadoop_setup/
}
downloadSoftware
while read -r line
do
    echo "Copy software to machine: ***********************************************************************************"$line
    name="$line"
    copySoftware $name 
    echo "Done for machine        : ***********************************************************************************"$line
done < "$filename"


while read -r line
do
    name="$line"
    echo "${RED}Installing for Node:##################################################################################################### "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/install_phoenix.sh 
    echo "Done for Node:*************************************************************************************************************  "$name
done < "$filename"


