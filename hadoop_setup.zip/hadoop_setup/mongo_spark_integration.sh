scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@nn1.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@nn1.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/


scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@nn2.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@nn2.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/


scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@dn1.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@dn1.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/

scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@dn2.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@dn2.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/


scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@dn3.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@dn3.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/


scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@jn1.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@jn1.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/

scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@jn2.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@jn2.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/

scp /root/hadoop_setup/resources/mongo-spark-connector_2.11-2.0.0.jar  root@jn3.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/
scp /root/hadoop_setup/resources/mongo-java-driver-3.2.2.jar           root@jn3.local:/opt/software/spark-2.1.1-bin-hadoop2.7/jars/

