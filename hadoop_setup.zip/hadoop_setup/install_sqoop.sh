installSQOOP(){
   rm -rf  /opt/software/sqoop1.4.6
   wget "http://mirror.fibergrid.in/apache/sqoop/1.4.6/sqoop-1.4.6.bin__hadoop-0.23.tar.gz" -P /$(whoami)/hadoop_setup/
   tar -zxvf /$(whoami)/hadoop_setup/sqoop-1.4.6.bin__hadoop-0.23.tar.gz -C /$(whoami)/hadoop_setup/
   mv /$(whoami)/hadoop_setup/sqoop-1.4.6.bin__hadoop-0.23        /opt/software/sqoop1.4.6
   rm  -r  /$(whoami)/hadoop_setup/sqoop-1.4.6.bin__hadoop-0.23.tar.gz
}
configureSQOOP(){
   cp /$(whoami)/hadoop_setup/resources/sqoop-site.xml    /opt/software/sqoop1.4.6/conf/sqoop-site.xml
   cp /$(whoami)/hadoop_setup/resources/sqoop-env.sh    /opt/software/sqoop1.4.6/conf/sqoop-env.sh
   cp /$(whoami)/hadoop_setup/resources/mysql-connector-java-5.1.23-bin.jar /opt/software/sqoop1.4.6/lib/
   chmod 777 -R /opt/software/sqoop1.4.6

}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "SQOOP_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then

     echo "Setting SQOOP_HOME in .bashrc file path..."
     echo "export SQOOP_HOME=/opt/software/sqoop1.4.6" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/sqoop1.4.6/bin" >> ~/.bashrc
     exec bash
  else
    echo "SQOOP path is already exist in .bashrc file, skipping the path..."
  fi
}

installSQOOP
configureSQOOP
refreshBashRC