# /bin/bash
CURDATE=$(date +%Y-%m-%d)
ZOOKEEPER_NODE_LIST="jn1,jn2,jn3"
isZooKeeperNode(){
  IS_ELIGBLE_FOR_ZOOKEEPER=`echo $ZOOKEEPER_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_ZOOKEEPER" ]; then
       return 0    
   else
       return 1
  fi
}
createDirectory(){
  isZooKeeperNode
  if [ "$?" == "1" ]; then
       mkdir -p /opt/software/zookeeper/data
       mkdir -p /opt/software/zookeeper/logs
       mkdir -p /opt/software/journal/node/local/data
   fi
    mkdir -p /opt/software/hdfsdrive 
    mkdir -p /opt/software/hdfsdrive/datanode
    mkdir -p /opt/software/hdfsdrive/datanode
    mkdir -p /opt/software/hadoop/logs 
}
assignPermission(){
   sudo chown $(whoami) -R   /opt/software/
   sudo chmod 777 -R  /opt/software/
}
cleanSoftware()
{
   rm -rf /opt/software/*
   mkdir -p /opt/software
}
extractAllSoft(){
    tar -zxvf /$(whoami)/hadoop_setup/jdk-8u151-linux-x64.tar.gz -C /$(whoami)/hadoop_setup/
    tar -zxvf /$(whoami)/hadoop_setup/hadoop-2.7.4.tar.gz -C /$(whoami)/hadoop_setup/
  isZooKeeperNode
  if [ "$?" == "1" ]; then
      tar -zxvf /$(whoami)/hadoop_setup/zookeeper-3.4.10.tar.gz  -C /$(whoami)/hadoop_setup/

  fi
}
copyResources(){
     echo "copyResources---------------------------------------------> $(hostname) "
     mv /$(whoami)/hadoop_setup/jdk1.8.0_151       /opt/software/jdk1.8
     mv /$(whoami)/hadoop_setup/hadoop-2.7.4/*      /opt/software/hadoop
    
    isZooKeeperNode
    if [ "$?" == "1" ]; then
         mv /$(whoami)/hadoop_setup/zookeeper-3.4.10/*          /opt/software/zookeeper
   	  cp /$(whoami)/hadoop_setup/resources/zoo.cfg          /opt/software/zookeeper/conf/zoo.cfg
         rm -rf /$(whoami)/hadoop_setup/zookeeper-3.4.10
	  rm -rf /$(whoami)/hadoop_setup/*.tar.gz*
    fi
     cp /$(whoami)/hadoop_setup/resources/core-site.xml    /opt/software/hadoop/etc/hadoop/core-site.xml
     cp /$(whoami)/hadoop_setup/resources/hdfs-site.xml    /opt/software/hadoop/etc/hadoop/hdfs-site.xml	
     cp /$(whoami)/hadoop_setup/resources/mapred-site.xml  /opt/software/hadoop/etc/hadoop/mapred-site.xml
     cp /$(whoami)/hadoop_setup/resources/yarn-site.xml    /opt/software/hadoop/etc/hadoop/yarn-site.xml
     cp /$(whoami)/hadoop_setup/resources/hadoop-env.sh    /opt/software/hadoop/etc/hadoop/hadoop-env.sh
     cp /$(whoami)/hadoop_setup/resources/yarn-env.sh      /opt/software/hadoop/etc/hadoop/yarn-env.sh
     rm -rf /$(whoami)/hadoop_setup/*.tar.gz*
     rm -rf /$(whoami)/hadoop_setup/hadoop-2.7.4

}
createZookeeperIndexFile(){
   isZooKeeperNode
   if [ "$?" == "1" ]; then
      NUMBER=$(echo "$(hostname)" | tr -dc '0-9')
       touch /opt/software/zookeeper/data/myid
       chown $(whoami) -R /opt/software/zookeeper/data/myid
       chmod 777 -R /opt/software/zookeeper/data/myid 
      echo "$NUMBER" > /opt/software/zookeeper/data/myid
    fi
}
refreshBashRC(){
  HAS_PATH=` cat ~/.bashrc |grep "HADOOP_PREFIX"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting .bashrc file path..."
      cat /$(whoami)/hadoop_setup/resources/bashrc >> ~/.bashrc
     exec bash
  else
    echo "Hadoop path is already exist in .bashrc file, skipping the path..."
  fi
}
cleanSoftware
extractAllSoft
createDirectory
copyResources
assignPermission
createZookeeperIndexFile
refreshBashRC

