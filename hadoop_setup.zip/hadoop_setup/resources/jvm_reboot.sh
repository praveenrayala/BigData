export JAVA_HOME=/opt/software/jdk1.8
killall -9 java