if [ "nn1" != "$(hostname)" ]; then
  echo "Cleaning hadoop_setup folder from host: "$(hostname)
  rm -rf ~/hadoop_setup
  rm -rf /opt/software
  rm -rf /opt/software/hdfsdrive
fi
if [ "nn1" == "$(hostname)" ]; then
 echo "Cleaning hadoop_setup folder from host: "$(hostname)
 rm -rf /opt/software/hdfsdrive
fi
if [ "nn2" == "$(hostname)" ]; then
 echo "Cleaning hadoop_setup folder from host: "$(hostname)
 rm -rf /opt/software
fi

