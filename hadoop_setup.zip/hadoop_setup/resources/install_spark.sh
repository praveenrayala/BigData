#/bash/bin
installSpark(){
   sudo rm -rf /opt/software/spark-2.1.1-bin-hadoop2.7
   sudo tar -zxvf /$(whoami)/hadoop_setup/spark-2.1.1-bin-hadoop2.7.tgz -C /$(whoami)/hadoop_setup/
   sudo mv /$(whoami)/hadoop_setup/spark-2.1.1-bin-hadoop2.7        /opt/software/spark-2.1.1-bin-hadoop2.7
   sudo rm  -r  /$(whoami)/hadoop_setup/spark-2.1.1-bin-hadoop2.7.tgz
}
configureSpark(){
   sudo cp /$(whoami)/hadoop_setup/resources/core-site.xml          /opt/software/spark-2.1.1-bin-hadoop2.7/conf/core-site.xml
   sudo cp /$(whoami)/hadoop_setup/resources/hdfs-site.xml          /opt/software/spark-2.1.1-bin-hadoop2.7/conf/hdfs-site.xml
   sudo cp /$(whoami)/hadoop_setup/resources/hive-site.xml          /opt/software/spark-2.1.1-bin-hadoop2.7/conf/hive-site.xml
   sudo cp /$(whoami)/hadoop_setup/resources/spark-env.sh           /opt/software/spark-2.1.1-bin-hadoop2.7/conf/spark-env.sh
   sudo cp /$(whoami)/hadoop_setup/resources/log4j.properties    /opt/software/spark-2.1.1-bin-hadoop2.7/conf/log4j.properties
   sudo cp /$(whoami)/hadoop_setup/resources/spark-defaults.conf    /opt/software/spark-2.1.1-bin-hadoop2.7/conf/spark-defaults.conf
   sudo cp /$(whoami)/hadoop_setup/resources/slaves                 /opt/software/spark-2.1.1-bin-hadoop2.7/conf/slaves
   sudo cp /$(whoami)/hadoop_setup/resources/mysql-connector-java-5.1.23-bin.jar /opt/software/spark-2.1.1-bin-hadoop2.7/jars/
   sudo chmod 777 -R /opt/software/spark-2.1.1-bin-hadoop2.7
}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "SPARK_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting SPARK_HOME in .bashrc file path..."
     echo "export SPARK_HOME=/opt/software/spark-2.1.1-bin-hadoop2.7" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/spark-2.1.1-bin-hadoop2.7/bin" >> ~/.bashrc
     exec bash
  else
    echo "SPARK path is already exist in .bashrc file, skipping the path..."
  fi
}

installSpark
configureSpark
refreshBashRC