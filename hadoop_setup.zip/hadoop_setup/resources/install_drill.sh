DRILL_NODE_LIST="nn1,jn1,jn2,jn3,dn1,dn2,dn3,dn4"
installDrill(){
   rm -rf /opt/software/drill
   mkdir -p /opt/software/drill
   tar -zxvf /$(whoami)/hadoop_setup/apache-drill-1.11.0.tar.gz -C /$(whoami)/hadoop_setup/
   mv /$(whoami)/hadoop_setup/apache-drill-1.11.0/*        /opt/software/drill
   cp -rf ./apache-drill-1.11.0/*        /opt/software/drill
   #rm  -r  /$(whoami)/hadoop_setup/apache-drill-1.11.0.tar.gz
}
configureDrill(){
   echo "configureDrill........................................"
   cp /$(whoami)/hadoop_setup/resources/drill-override.conf     /opt/software/drill/conf/drill-override.conf
   cp /$(whoami)/hadoop_setup/resources/core-site.xml     /opt/software/drill/conf/core-site.xml 
   cp /$(whoami)/hadoop_setup/resources/hdfs-site.xml     /opt/software/drill/conf/hdfs-site.xml
   chmod 777 -R  /opt/software/drill
}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "DRILL_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting DRILL_HOME in .bashrc file path..."
     echo "export DRILL_HOME=/opt/software/drill" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/drill/bin" >> ~/.bashrc
     exec bash
  else
    echo "DRILL_HOME  path is already exist in .bashrc file, skipping the path..."
  fi
}
isDrillNode(){
  IS_ELIGBLE_FOR_DRILL=`echo $DRILL_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_DRILL" ]; then
       return 0    
   else
       return 1
  fi
}
cleanDrill(){
  rm -r /opt/software/drill
}
isDrillNode
if [ "$?" == "1" ]; then 
  cleanDrill
  installDrill
  configureDrill
  refreshBashRC
fi

