export JAVA_HOME=/opt/software/jdk1.8
if [ "jn1" == "$(hostname)" ]; then
   running_kafka_broker_pid=`ps axf | grep "kafka" | grep -v grep | awk '{print "kill -9 " $1}'`
   `echo $running_kafka_broker_pid`
    sleep 10
    /opt/software/kafka_2.10/bin/kafka-server-start.sh /opt/software/kafka_2.10/config/kafka_broker_server1.properties  > /tmp/kafka_broker_server1.log &
    echo "STARTED: Broker-1 on host- "$(hostname)
elif [ "jn2" == "$(hostname)" ]; then
   running_kafka_broker_pid=`ps axf | grep "kafka" | grep -v grep | awk '{print "kill -9 " $1}'`
   `echo $running_kafka_broker_pid`
    sleep 10
   /opt/software/kafka_2.10/bin/kafka-server-start.sh /opt/software/kafka_2.10/config/kafka_broker_server2.properties  > /tmp/kafka_broker_server2.log &
 echo "STARTED: Broker-1 on host- "$(hostname)
elif [ "jn3" == "$(hostname)" ]; then
 running_kafka_broker_pid=`ps axf | grep "kafka" | grep -v grep | awk '{print "kill -9 " $1}'`
   `echo $running_kafka_broker_pid`
   sleep 10
  /opt/software/kafka_2.10/bin/kafka-server-start.sh /opt/software/kafka_2.10/config/kafka_broker_server3.properties  > /tmp/kafka_broker_server2.log &
   echo "STARTED: Broker-1 on host- "$(hostname)
fi

