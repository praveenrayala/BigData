DRILL_NODE_LIST="nn1,jn1,jn2,jn3,dn1,dn2,dn3,dn4"
isDrillNode(){
  IS_ELIGBLE_FOR_DRILL=`echo $DRILL_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_DRILL" ]; then
       return 0    
   else
       return 1
  fi
}
isDrillNode
if [ "$?" == "1" ]; then 
 drillbit.sh restart
fi
