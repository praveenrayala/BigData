export JAVA_HOME=/opt/software/jdk1.8
export HADOOP_PREFIX=/opt/software/hadoop
export HADOOP_HOME=/opt/software/hadoop
export HADOOP_MAPRED_HOME=$HADOOP_HOME
export HADOOP_HDFS_HOME=$HADOOP_HOME
export YARN_HOME=$HADOOP_HOME
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export HADOOP_OPTS="-Djava.library.path=$HADOOP_HOME/lib"
export HADOOP_COMMON_HOME=$HADOOP_HOME
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export YARN_CONF_DIR=$HADOOP_HOME/etc/hadoop
export ZOOKEEPER_HOME=/opt/software/zookeeper
export PATH=$PATH:$HOME/bin:$JAVA_HOME/bin:$HADOOP_PREFIX/bin:$HADOOP_HOME/sbin
export PATH=$PATH:$ZOOKEEPER_HOME/bin
export HADOOP_CLASSPATH=$HADOOP_CLASSPATH:/opt/software/hadoop/share/hadoop/common

ZOOKEEPER_NODE_LIST="jn1,jn2,jn3"
DATA_NODE_LIST="jn1,jn2,jn3,dn1,dn2,dn3,dn4,dn5"
startZooKeeper(){
   /opt/software/zookeeper/bin/zkServer.sh stop
   /opt/software/zookeeper/bin/zkServer.sh start
   /opt/software/zookeeper/bin/zkServer.sh status
}
startJournal(){
 hadoop-daemon.sh stop journalnode
 hadoop-daemon.sh start journalnode
}
startNameNode(){
 
    if [ "nn1" == "$(hostname)" ]; then   
       hadoop-daemon.sh stop  namenode
       hadoop-daemon.sh start namenode
       startZKFC
       startReourceManager
       staratHistoryServer
    elif [ "nn2" == "$(hostname)" ] ; then
    
      # hdfs namenode -bootstrapStandby 
       hadoop-daemon.sh stop namenode
       hadoop-daemon.sh start namenode
       startZKFC
       startReourceManager
    fi
  
   
}
startZKFC(){
  hadoop-daemon.sh stop  zkfc
  hadoop-daemon.sh start zkfc
}
startDataNode(){
  hadoop-daemon.sh stop datanode
  hadoop-daemon.sh start datanode
}
startReourceManager(){
 yarn-daemon.sh stop resourcemanager
 yarn-daemon.sh start resourcemanager
}
startNodeManager(){
 yarn-daemon.sh stop nodemanager
 yarn-daemon.sh start nodemanager
}
staratHistoryServer(){
  mr-jobhistory-daemon.sh --config $HADOOP_CONF_DIR stop historyserver
  mr-jobhistory-daemon.sh --config $HADOOP_CONF_DIR start historyserver
}
isZooKeeperNode(){
  IS_ELIGBLE_FOR_ZOOKEEPER=`echo $ZOOKEEPER_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_ZOOKEEPER" ]; then
       return 0    
   else
       return 1
  fi
}
DATA_NODE_LIST="jn1,jn2,jn3,dn1,dn2,dn3,dn4,dn5"
isDataNode(){
  IS_ELIGBLE_FOR_DATANODE=`echo $DATA_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_DATANODE" ]; then
       return 0    
   else
       return 1
  fi
}
# ****************************************************************************************************************************************************************************************** 
isZooKeeperNode
if [ "$?" == "1" ]; then
    startZooKeeper 
    startJournal
fi
startNameNode
isDataNode
if [ "$?" == "1" ]; then
    startDataNode 
    startNodeManager    
fi