HBASE_NODE_LIST="nn1,jn1,jn2,jn3,dn1,dn2,dn3"
installPhoenix(){
   #sudo wget "http://redrockdigimark.com/apachemirror/phoenix/phoenix-4.7.0-HBase-1.1/bin/phoenix-4.7.0-HBase-1.1-bin.tar.gz" -P /home/$(whoami)/hadoop_setup/
   sudo tar -zxvf /home/$(whoami)/hadoop_setup/phoenix-4.7.0-HBase-1.1-bin.tar.gz -C /home/$(whoami)/hadoop_setup/
   sudo mv /home/$(whoami)/hadoop_setup/phoenix-4.7.0-HBase-1.1-bin        /opt/software/phoenix-4.7
   sudo rm  -r  /home/$(whoami)/hadoop_setup/phoenix-4.7.0-HBase-1.1-bin.tar.gz
}
configurePhoenixHBase(){
   sudo cp /opt/software/phoenix-4.7/phoenix-core-4.7.0-HBase-1.1.jar     /opt/software/hbase/lib/
   sudo cp /opt/software/phoenix-4.7/phoenix-4.7.0-HBase-1.1-server.jar   /opt/software/hbase/lib/
   sudo chmod 777 -R  /opt/software/hbase
   sudo chmod 777 -R  /opt/software/phoenix-4.7
}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "PHOENIX_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting PHOENIX_HOME in .bashrc file path..."
     echo "export PHOENIX_HOME=/opt/software/phoenix-4.7" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/phoenix-4.7/bin" >> ~/.bashrc
     exec bash
  else
    echo "Phoenix path is already exist in .bashrc file, skipping the path..."
  fi
}
isPhonexNode(){
  IS_ELIGBLE_FOR_PHOENIX=`echo $HBASE_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_PHOENIX" ]; then
       return 0    
   else
       return 1
  fi
}
cleanPhonexNode(){
  sudo rm -r /opt/software/hbase/lib/phoenix-4.7.0-HBase-1.1-server.jar
  sudo rm -r /opt/software/hbase/lib/phoenix-core-4.7.0-HBase-1.1.jar
  sudo rm -r /opt/software/phoenix-4.7
}
isPhonexNode
if [ "$?" == "1" ]; then 
  cleanPhonexNode
  installPhoenix
  configurePhoenixHBase
  refreshBashRC
fi
