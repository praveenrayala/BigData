KAFKA_NODE_LIST="jn1,jn2,jn3"
installKAFKA(){
  
   sudo tar -zxvf /$(whoami)/hadoop_setup/kafka_2.10-0.10.0.0.tgz -C /$(whoami)/hadoop_setup/
   sudo mv /$(whoami)/hadoop_setup/kafka_2.10-0.10.0.0        /opt/software/kafka_2.10
   sudo rm  -r  /$(whoami)/hadoop_setup/kafka_2.10-0.10.0.0.tgz
}
configureKAFKA(){
   if [ "jn1" == "$(hostname)" ]; then
  	 sudo cp /$(whoami)/hadoop_setup/resources/kafka_broker_server1.properties     /opt/software/kafka_2.10/config/kafka_broker_server1.properties
   elif [ "jn2" == "$(hostname)" ]; then
   	sudo cp /$(whoami)/hadoop_setup/resources/kafka_broker_server2.properties     /opt/software/kafka_2.10/config/kafka_broker_server2.properties
   elif [ "jn3" == "$(hostname)" ]; then
  	 sudo cp /$(whoami)/hadoop_setup/resources/kafka_broker_server3.properties     /opt/software/kafka_2.10/config/kafka_broker_server3.properties
   fi
   sudo chmod 777 -R  /opt/software/kafka_2.10
}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "KAFKA_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting KAFKA_HOME in .bashrc file path..."
     echo "export KAFKA_HOME=/opt/software/kafka_2.10" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/kafka_2.10/bin" >> ~/.bashrc
     exec bash
  else
    echo "KAFKA  path is already exist in .bashrc file, skipping the path..."
  fi
}
isKAFKANode(){
  IS_ELIGBLE_FOR_KAFKA=`echo $KAFKA_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_KAFKA" ]; then
       return 0    
   else
       return 1
  fi
}
cleanKAFKA(){
  sudo rm -r /opt/software/kafka_2.10
}
isKAFKANode
if [ "$?" == "1" ]; then 
  cleanKAFKA
  installKAFKA
  configureKAFKA
  refreshBashRC
fi
