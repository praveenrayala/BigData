copyResources(){
    #cp -f /$(whoami)/hadoop_setup/resources/zoo.cfg          /opt/software/zookeeper/conf/zoo.cfg  
    cp -f /$(whoami)/hadoop_setup/resources/core-site.xml    /opt/software/hadoop/etc/hadoop/core-site.xml
    cp -f /$(whoami)/hadoop_setup/resources/hdfs-site.xml    /opt/software/hadoop/etc/hadoop/hdfs-site.xml	
    cp -f /$(whoami)/hadoop_setup/resources/mapred-site.xml  /opt/software/hadoop/etc/hadoop/mapred-site.xml
    cp -f /$(whoami)/hadoop_setup/resources/yarn-site.xml    /opt/software/hadoop/etc/hadoop/yarn-site.xml
    cp -f /$(whoami)/hadoop_setup/resources/hadoop-env.sh    /opt/software/hadoop/etc/hadoop/hadoop-env.sh
    cp -f /$(whoami)/hadoop_setup/resources/yarn-env.sh      /opt/software/hadoop/etc/hadoop/yarn-env.sh

    cp -f /$(whoami)/hadoop_setup/resources/yarn-env.sh      /opt/software/hadoop/etc/hadoop/yarn-env.sh
    cp -f /$(whoami)/hadoop_setup/resources/yarn-env.sh      /opt/software/hadoop/etc/hadoop/yarn-env.sh
    cp -f /$(whoami)/hadoop_setup/resources/yarn-env.sh      /opt/software/hadoop/etc/hadoop/yarn-env.sh

    #cp -f /$(whoami)/hadoop_setup/resources/slave            /opt/software/hadoop/etc/hadoop/slave     								 
}
copyResources