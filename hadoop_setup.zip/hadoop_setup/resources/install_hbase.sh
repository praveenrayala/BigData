HBASE_NODE_LIST="NN1.local,NN2.local,DN1.local,DN2.local,DN3.local,JN1.local,JN2.local,JN3.local"
installHBase(){
   #sudo wget "http://mirror.fibergrid.in/apache/hbase/stable/hbase-1.1.5-bin.tar.gz" -P /$(whoami)/hadoop_setup/
   tar -zxvf /$(whoami)/hadoop_setup/hbase-1.2.4-bin.tar.gz -C /$(whoami)/hadoop_setup/
   mv /$(whoami)/hadoop_setup/hbase-1.2.4        /opt/software/hbase
   rm  -r  /$(whoami)/hadoop_setup/hbase-1.1.5-bin.tar.gz
}
configureHBase(){
   cp /$(whoami)/hadoop_setup/resources/hbase-site.xml     /opt/software/hbase/conf/hbase-site.xml
   cp /$(whoami)/hadoop_setup/resources/hbase-env.sh       /opt/software/hbase/conf/hbase-env.sh
   cp /$(whoami)/hadoop_setup/resources/regionservers      /opt/software/hbase/conf/regionservers
   cp /$(whoami)/hadoop_setup/resources/core-site.xml      /opt/software/hbase/conf/core-site.xml
   cp /$(whoami)/hadoop_setup/resources/hdfs-site.xml      /opt/software/hbase/conf/hdfs-site.xml	
   chmod 777 -R  /opt/software/hbase
}
refreshBashRC(){
  HAS_PATH=`sudo cat ~/.bashrc |grep "HBASE_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting HBASE_HOME in .bashrc file path..."
     echo "export HBASE_HOME=/opt/software/hbase" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/hbase/bin" >> ~/.bashrc
     exec bash
  else
    echo "HBase  path is already exist in .bashrc file, skipping the path..."
  fi
}
isHBaseNode(){
  IS_ELIGBLE_FOR_HBASE=`echo $HBASE_NODE_LIST |grep "$(hostname)"|wc -l`
  if [ "0" == "$IS_ELIGBLE_FOR_HBASE" ]; then
       return 0    
   else
       return 1
  fi
}
cleanHbase(){
  rm -r /opt/software/hbase
}
isHBaseNode
if [ "$?" == "1" ]; then 
  cleanHbase
  installHBase
  configureHBase
  refreshBashRC
fi
