configureSpark(){
   cp /$(whoami)/hadoop_setup/resources/core-site.xml          /opt/software/spark-1.6_hadoop2.6/conf/core-site.xml
   cp /$(whoami)/hadoop_setup/resources/hdfs-site.xml          /opt/software/spark-1.6_hadoop2.6/conf/hdfs-site.xml
   cp /$(whoami)/hadoop_setup/resources/hive-site.xml          /opt/software/spark-1.6_hadoop2.6/conf/hive-site.xml
   cp /$(whoami)/hadoop_setup/resources/spark-env.sh           /opt/software/spark-1.6_hadoop2.6/conf/spark-env.sh
   cp /$(whoami)/hadoop_setup/resources/log4j.properties    /opt/software/spark-1.6_hadoop2.6/conf/log4j.properties
   cp /$(whoami)/hadoop_setup/resources/spark-defaults.conf    /opt/software/spark-1.6_hadoop2.6/conf/spark-defaults.conf
   cp /$(whoami)/hadoop_setup/resources/slaves                 /opt/software/spark-1.6_hadoop2.6/conf/slaves
   cp /$(whoami)/hadoop_setup/resources/mysql-connector-java-5.1.23-bin.jar /opt/software/spark-1.6_hadoop2.6/lib/
   chmod 777 -R /opt/software/spark-1.6_hadoop2.6
}
configureSpark