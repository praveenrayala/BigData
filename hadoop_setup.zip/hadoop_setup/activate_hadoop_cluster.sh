filename="/$(whoami)/hadoop_setup/nodes"
while read -r line
do
    name="$line"
    echo "Activating node ************************************************************************************************ "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/activate_hadoop.sh 
done < "$filename"

