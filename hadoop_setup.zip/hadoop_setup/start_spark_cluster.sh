hadoop fs -mkdir -p  hdfs://mycluster:8020/spark_event_log
$SPARK_HOME/sbin/stop-all.sh
$SPARK_HOME/sbin/start-all.sh