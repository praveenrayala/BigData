
installHive(){
   wget "http://redrockdigimark.com/apachemirror/hive/hive-2.1.1/apache-hive-2.1.1-bin.tar.gz" -P /$(whoami)/hadoop_setup/
   tar -zxvf /$(whoami)/hadoop_setup/apache-hive-2.1.1-bin.tar.gz -C /$(whoami)/hadoop_setup/
   mv /$(whoami)/hadoop_setup/apache-hive-2.1.1-bin        /opt/software/hive
   mv /$(whoami)/hadoop_setup/apache-hive-2.1.1-bin/lib/*       /opt/software/hive/lib/
   rm  -r  /$(whoami)/hadoop_setup/apache-hive-2.1.1-bin.tar.gz
   rm  -r  /$(whoami)/hadoop_setup/apache-hive-*
}
configureHive(){
   cp /$(whoami)/hadoop_setup/resources/hive-site.xml    /opt/software/hive/conf/hive-site.xml
   cp /$(whoami)/hadoop_setup/resources/mysql-connector-java-5.1.23-bin.jar /opt/software/hive/lib/
}
refreshBashRC(){
  HAS_PATH=`cat ~/.bashrc |grep "HIVE_HOME"|wc -l`
  if [ "0" == "$HAS_PATH" ]; then
     echo "Setting HIVE_HOME in .bashrc file path..."
     echo "export HIVE_HOME=/opt/software/hive" >> ~/.bashrc
     echo "export PATH=\$PATH:/opt/software/hive/bin" >> ~/.bashrc
     exec bash
  else
    echo "Hive  path is already exist in .bashrc file, skipping the path..."
  fi
}

installHive
configureHive
refreshBashRC
