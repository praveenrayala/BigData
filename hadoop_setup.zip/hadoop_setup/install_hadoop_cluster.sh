filename="/$(whoami)/hadoop_setup/nodes"
downloadSoftware()
{
   rm -rf /opt/software/*
   mkdir -p /opt/software   
   wget "http://apache.mirror.globo.tech/zookeeper/stable/zookeeper-3.4.10.tar.gz" -P /$(whoami)/hadoop_setup/
   wget --no-cookies --no-check-certificate --header "Cookie: gpw_e24=http%3A%2F%2Fwww.oracle.com%2F; oraclelicense=accept-securebackup-cookie" "http://download.oracle.com/otn-pub/java/jdk/8u151-b12/e758a0de34e24606bca991d704f6dcbf/jdk-8u151-linux-x64.tar.gz" -P /$(whoami)/hadoop_setup/
   wget "http://muug.ca/mirror/apache-dist/hadoop/common/hadoop-2.7.4/hadoop-2.7.4.tar.gz"  -P /$(whoami)/hadoop_setup/
}
copySoftware(){
   scp /$(whoami)/hadoop_setup/zookeeper-3.4.10.tar.gz $(whoami)@$1:/$(whoami)/hadoop_setup/
   scp /$(whoami)/hadoop_setup/jdk-8u151-linux-x64.tar.gz $(whoami)@$1:/$(whoami)/hadoop_setup/
   scp /$(whoami)/hadoop_setup/hadoop-2.7.4.tar.gz $(whoami)@$1:/$(whoami)/hadoop_setup/

}
downloadSoftware
while read -r line
do
    echo "Copy software to machine: ***********************************************************************************"$line
    name="$line"
    copySoftware $name 
    echo "Done for machine        : ***********************************************************************************"$line
done < "$filename"

while read -r line
do
    name="$line"
    echo "Installing hadoop for node ************************************************************************************************ "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/install_hadoop_packages.sh 
done < "$filename"

