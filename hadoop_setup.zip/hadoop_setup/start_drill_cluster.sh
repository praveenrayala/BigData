filename="/$(whoami)/hadoop_setup/nodes"
while read -r line
do
    name="$line"
    echo "${RED}Starting Drill on  Node:##################################################################################################### "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/start_drill.sh
    echo "Done for Node:*************************************************************************************************************  "$name
done < "$filename"

