filename="/$(whoami)/hadoop_setup/nodes"
while read -r line
do
    name="$line"
    echo "Restating  node ************************************************************************************************ "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/start_hadoop.sh 
done < "$filename"

