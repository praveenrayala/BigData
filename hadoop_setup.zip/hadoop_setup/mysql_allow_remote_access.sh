cp /$(whoami)/hadoop_setup/resources/my.cnf /etc/mysql/my.cnf
/sbin/service mysqld restart
#Change GRANT privilege
mysql -u root -phadoop -Bse "GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'NN1.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
#mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'10.128.0.2' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON demo.* to 'root'@'%' IDENTIFIED BY 'hadoop';"

mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'DN1.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'DN2.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'DN3.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'JN1.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'JN2.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "GRANT ALL PRIVILEGES ON *.* TO 'root'@'JN3.local' IDENTIFIED BY 'hadoop' WITH GRANT OPTION;"
mysql -u root -phadoop -Bse  "FLUSH PRIVILEGES;"
/sbin/service  restart
