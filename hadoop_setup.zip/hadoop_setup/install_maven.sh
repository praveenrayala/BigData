#sudo apt-get update
apt-get install maven