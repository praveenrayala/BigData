stop-hbase.sh
start-hbase.sh