filename="/$(whoami)/hadoop_setup/nodes"
while read -r line
do
    name="$line"
    echo "Copying to  node ************************************************************************************************ "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/copy_hadoop_resources.sh
done < "$filename"
#./restart_hadoop_cluster.sh

