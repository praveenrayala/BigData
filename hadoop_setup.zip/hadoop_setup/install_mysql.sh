installMySQL(){
 yum  update
 export DEBIAN_FRONTEND="noninteractive"
 debconf-set-selections <<< "mysql-server mysql-server/root_password password hadoop"
 debconf-set-selections <<< "mysql-server mysql-server/root_password_again password hadoop"
 apt-get install -y mysql-server-5.6
 mysql_secure_installation
}
installMySQL