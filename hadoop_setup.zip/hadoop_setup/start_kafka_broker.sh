filename="/$(whoami)/hadoop_setup/nodes"
while read -r line
do
    name="$line"
    echo "${RED}Starting Broker on  Node:##################################################################################################### "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/start_kafka_broker.sh
    echo "Done for Node:*************************************************************************************************************  "$name
done < "$filename"

