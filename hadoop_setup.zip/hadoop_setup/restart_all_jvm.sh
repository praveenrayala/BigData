filename="/$(whoami)/hadoop_setup/nodes"
while read -r line
do
    name="$line"
    echo "Restarting JVM for node: "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/jvm_reboot.sh 
done < "$filename"
