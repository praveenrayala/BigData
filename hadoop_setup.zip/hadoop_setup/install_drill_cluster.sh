filename="/$(whoami)/hadoop_setup/nodes"
downloadSoftware()
{
  sudo wget "http://redrockdigimark.com/apachemirror/drill/drill-1.11.0/apache-drill-1.11.0.tar.gz" -P /$(whoami)/hadoop_setup/
}
copySoftware(){
   scp /$(whoami)/hadoop_setup/apache-drill-1.11.0.tar.gz $(whoami)@$1:/$(whoami)/hadoop_setup/
}
downloadSoftware
while read -r line
do
    echo "Copy software to machine: ***********************************************************************************"$line
    name="$line"
    copySoftware $name 
    echo "Done for machine        : ***********************************************************************************"$line
done < "$filename"

while read -r line
do
    name="$line"
    echo "${RED}Installing Drill for Node:##################################################################################################### "$name
    ssh $(whoami)@$name 'bash -s' < /$(whoami)/hadoop_setup/resources/install_drill.sh 
    echo "Done for Node:*************************************************************************************************************  "$name
done < "$filename"
